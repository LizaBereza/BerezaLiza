﻿namespace Domain1
{
    public class Class1
    {

    }
}